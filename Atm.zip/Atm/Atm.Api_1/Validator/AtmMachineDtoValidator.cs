﻿using Atm.Api_1.Data.Entities;
using Atm.Api_1.DPO;
using FluentValidation;

namespace Atm.Api_1.Validator
{
    public class AtmMachineDtoValidator : AbstractValidator<AtmMachineDto>
    {
        public AtmMachineDtoValidator() 
        {
            // Name validation
            RuleFor(x => x.Name)
                .NotEmpty().WithMessage("İsim gereklidir")
                .MaximumLength(50).WithMessage("İsim en fazla 20 karakter olabilir");

            // Adress validation
            RuleFor(x => x.Adress)
                .NotEmpty().WithMessage("Adres gereklidir");

            // Latitude validation
            RuleFor(x => x.Latitude)
                .NotEmpty().WithMessage("Enlem gereklidir")
                .InclusiveBetween(-90, 90).WithMessage("Enlem -90 ile 90 arasında olmalıdır");

            // Longitude validation
            RuleFor(x => x.Longitude)
                .NotEmpty().WithMessage("Boylam gereklidir")
                .InclusiveBetween(-180, 180).WithMessage("Boylam -180 ile 180 arasında olmalıdır");

            // DistrictId validation
            RuleFor(x => x.DistrictId)
                .GreaterThan(0).WithMessage("Geçerli bir ilçe ID gereklidir");

            // CityId validation
            RuleFor(x => x.CityId)
                .GreaterThan(0).WithMessage("Geçerli bir şehir ID gereklidir");


        }
    }
}
