﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Core.Repository.Concrete;
using Atm.Api_1.Data;
using Atm.Api_1.Services.Abstract;
using Atm.Api_1.Services.Concrete;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAutoMapper(typeof(Program).Assembly);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AtmDbContext>(options => options.UseSqlServer(connectionString));


//builder.Services.AddTransient<ICityRepository, CityRepository>();
builder.Services.AddTransient<ICityServices, CityServices>();
builder.Services.AddTransient<IDistrictServices, DistrictServices>();
builder.Services.AddTransient<IAtmMachineServices, AtmMachineServices>();
builder.Services.AddTransient<ICityRepository, CityRepository>();
builder.Services.AddTransient<IAtmMachineRepository, AtmMachineRepository>();
builder.Services.AddTransient<IDistrictRepository, DistrictRepository>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder => builder
            .WithOrigins("http://localhost:5173") // React uygulamanızın kökenini belirtin
            .AllowAnyHeader()
            .AllowAnyMethod());
});





var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();
app.UseCors("AllowSpecificOrigin");

app.MapControllers();

app.Run();
