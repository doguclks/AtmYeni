﻿namespace Atm.Api_1.Data.Entities
{
    public class City
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<Districts> Districts { get; set; }
        public ICollection<AtmMachine> AtmMachines { get; set; }
    }
}
