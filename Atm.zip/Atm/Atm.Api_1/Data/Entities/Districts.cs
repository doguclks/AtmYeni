﻿namespace Atm.Api_1.Data.Entities
{
    public class Districts
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CityId { get; set; }
        public virtual City City { get; set; }
        public ICollection<AtmMachine> AtmMachines { get; set; }

    }
}
