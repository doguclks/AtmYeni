﻿using Atm.Api_1.Data.Configure;
using Atm.Api_1.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Atm.Api_1.Data
{
    public class AtmDbContext:DbContext
    {
        public AtmDbContext(DbContextOptions<AtmDbContext> options):base(options)
        {
            
        }
        public DbSet<City> Cities { get; set; }
        public DbSet<Districts> Districts { get; set; }
        public DbSet<AtmMachine> AtmMachines { get; set; }

        //public DbSet<Personel> Personeles { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new CityConfiguration());
            modelBuilder.ApplyConfiguration(new DistrictConfiguration());
            modelBuilder.ApplyConfiguration(new AtmConfiguration());
            
        }


    }
}
