﻿
using Atm.Api_1.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Atm.Api_1.Data.Configure;



public class DistrictConfiguration : IEntityTypeConfiguration<Districts>
{
public void Configure(EntityTypeBuilder<Districts> builder)
{
    builder.HasKey(d => d.Id);
    builder.Property(d => d.Name)
            .IsRequired()
            .HasMaxLength(20)
            .HasColumnType("nvarchar(20)");
        
    builder.ToTable("Districts");



    }
}