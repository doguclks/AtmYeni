﻿using Atm.Api_1.Data.Entities;
using Atm.Api_1.DPO;
using Atm.Api_1.Dto;
using AutoMapper;

namespace Atm.Api_1.Mapper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<AtmMachine, AtmMachineDto>();
            CreateMap<AtmMachineDto, AtmMachine>();

            CreateMap<AtmMachine, AtmMachineResponseDto>();
            CreateMap<AtmMachineResponseDto, AtmMachine>();

            CreateMap<AtmMachineResponseDto, AtmMachineDto>();
            CreateMap<AtmMachineDto,AtmMachineResponseDto>();            

            CreateMap<City, CityDto>().ReverseMap();
            CreateMap<Districts, DistrictDto>().ReverseMap();

        }
    }
}
