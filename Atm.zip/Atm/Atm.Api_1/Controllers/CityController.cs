﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.Services.Abstract;
using Atm.Api_1.Services.Concrete;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace Atm.Api_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly ICityServices _cityServices;

        public CityController(ICityServices cityServices)
        {
            _cityServices = cityServices;
        }

        [HttpGet("GetList")]
        public IActionResult GetList()
        {
            var result = _cityServices.GetList();
            return Ok(result);
        }

        [HttpGet("Get/{id}")]
        public IActionResult Get(int id)
        {
            var result = _cityServices.Get(id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
        [HttpGet("GetByName")]
        public IActionResult CityFilter(string name)
        {
            var query = _cityServices.GetCitiesAsync(name);

            if (query == null)
            {
                return NotFound();
            }
            return Ok(query);
        }

    }
}
