﻿using Atm.Api_1.Services.Abstract;
using Microsoft.AspNetCore.Mvc;

namespace Atm.Api_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class DistrictController : ControllerBase
    {
        private readonly IDistrictServices _districtServices;

        public DistrictController(IDistrictServices districtServices)
        {
            _districtServices = districtServices; 
        }

        [HttpGet("GetList")]
        public IActionResult GetList()
        {
            var data = _districtServices.GetList();
            return Ok(data);
        }
        [HttpGet("Get{id}")]
        public IActionResult Get(int id)
        {
            var data = _districtServices.Get(id);
            if (data == null)
            {
                return NotFound();
            }
            return Ok(data);
        }
        [HttpGet("districts/{cityId}")]
        public async Task<IActionResult> GetDistrictsByCityName(int cityId)
        {
            var districts = await _districtServices.GetDistrictsByCityNameAsync(cityId);
            if (districts == null || !districts.Any())
            {
                return NotFound();
            }

            return Ok(districts);
        }

    }
    
}
