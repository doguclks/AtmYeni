﻿using Atm.Api_1.Data.Entities;
using Atm.Api_1.DPO;
using Atm.Api_1.Dto;
using Atm.Api_1.Pagination;
using Atm.Api_1.Services.Abstract;
using Atm.Api_1.Services.Concrete;
using Atm.Api_1.Validator;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Atm.Api_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AtmMachineController : ControllerBase
    {
        private readonly IAtmMachineServices _atmMachineServices;
        private readonly IMapper _mapper;

        public AtmMachineController(IAtmMachineServices atmMachineServices, IMapper mapper)
        {
            _atmMachineServices = atmMachineServices;
            _mapper = mapper;
        }

        [HttpGet("GetList")]
        public IActionResult GetList()
        {
            var atmMachines = _atmMachineServices.GetList();
            var atmMachineDTOs = _mapper.Map<IEnumerable<AtmMachineResponseDto>>(atmMachines);
            return Ok(atmMachines);
        }

        [HttpGet("GetById/{id}")]
        public IActionResult GetById(int id)
        {
            var atmMachine = _atmMachineServices.GetById(id);
            if (atmMachine == null)
            {
                return NotFound();
            }
            var atmMachineDTO = _mapper.Map<AtmMachineResponseDto>(atmMachine);
            return Ok(atmMachine);
        }

        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteById(int id)
        {
            var result = await _atmMachineServices.DeleteById(id);
            if (!result)
            {
                return NotFound();
            }
            return Ok(result);
        }


        [HttpPost("Create")]
        public IActionResult Add(AtmMachineDto atmMachineDTO)
        {
            var validator = new AtmMachineDtoValidator();
            var validationResult = validator.Validate(atmMachineDTO);
            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.Select(x => x.ErrorMessage)); //Hangi alanda ne bozukluk var .!

            }

            var atmMachine = _mapper.Map<AtmMachineResponseDto>(atmMachineDTO);
            _atmMachineServices.Add(atmMachine);


            return CreatedAtAction(nameof(GetById), new { id = atmMachine.Id }, atmMachineDTO);
        }
        [HttpPut("update")]
        public IActionResult Update2(AtmMachineDto dto)
        {

            _atmMachineServices.Update2(dto);


            return CreatedAtAction(nameof(GetById), new { id = dto.Id }, dto);
        }

        [HttpGet("Pagination")]

       public async  Task<ActionResult<IEnumerable<AtmMachineResponseDto>>> Pagination(PagingParameters pagingParameters)
        {
            return await _atmMachineServices.Pagination(pagingParameters);
        }
        



    }
}
