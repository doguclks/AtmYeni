﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Dto;

namespace Atm.Api_1.Services.Abstract
{
    public interface IDistrictServices
    {
        List<DistrictDto> GetList();
        DistrictDto Get(int id);
        Task<IEnumerable<DistrictDto>> GetDistrictsByCityNameAsync(int cityId);
    }
}
