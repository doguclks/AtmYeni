﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.DPO;
using Atm.Api_1.Dto;
using Atm.Api_1.Pagination;
using Atm.Api_1.Services.Concrete;

namespace Atm.Api_1.Services.Abstract
{
    public interface IAtmMachineServices
    {
        AtmMachineResponseDto GetById(int id);
        AtmMachineResponseDto Add(AtmMachineResponseDto atmMachineResponseDto);
        Task<bool> DeleteById(int id);

        Task<AtmMachine> Update(AtmMachine atmMachine);
        List<AtmMachineResponseDto> GetList();
        void Update2(AtmMachineDto dto);
        Task<PagedList<AtmMachineResponseDto>> Pagination(PagingParameters pagingParameters);




    }
}
