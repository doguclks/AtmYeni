﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.Dto;

namespace Atm.Api_1.Services.Abstract
{
    public interface ICityServices
    {
        Task<IEnumerable<City>> GetCitiesAsync(string name);
        CityDto Get(int id);
        List<CityDto> GetList();
    }
    
}
