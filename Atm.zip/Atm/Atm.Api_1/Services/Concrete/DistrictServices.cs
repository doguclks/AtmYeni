﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Core.Repository.Concrete;
using Atm.Api_1.Data;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.Dto;
using Atm.Api_1.Services.Abstract;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Atm.Api_1.Services.Concrete
{
    public class DistrictServices : IDistrictServices
    {
        private readonly IDistrictRepository _districtRepository;
        private readonly IMapper _mapper;

        public DistrictServices(IDistrictRepository districtRepository, IMapper mapper)
        {
            _districtRepository = districtRepository;
            _mapper = mapper;
        }

        public List<DistrictDto> GetList()
        {
            var districts = _districtRepository.GetAll();
            var districtDtos = _mapper.Map<List<DistrictDto>>(districts);
            return districtDtos;
        }

        public DistrictDto Get(int id)
        {
            var district = _districtRepository.Get(x => x.Id == id);
            var districtDto = _mapper.Map<DistrictDto>(district);
            return districtDto;
        }
        public async Task<IEnumerable<DistrictDto>> GetDistrictsByCityNameAsync(int cityId)
        {
            
            var districts = await _districtRepository.GetDistrictsByCityNameAsync(cityId);
            return districts.Select(d => new DistrictDto
            {
                Id = d.Id,
                Name = d.Name,
                CityId = d.CityId
            }).ToList();
        }
    }
}
