﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Core.Repository.Concrete;
using Atm.Api_1.Data;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.Dto;
using Atm.Api_1.Services.Abstract;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Atm.Api_1.Services.Concrete
{
    public class CityServices : ICityServices
    {
        private readonly ICityRepository _cityRepository;
        private readonly IMapper _mapper;

        public CityServices(ICityRepository cityRepository, IMapper mapper)
        {
            _cityRepository = cityRepository;
            _mapper = mapper;
        }

        public List<CityDto> GetList()
        {
            var cities = _cityRepository.GetAll();
            var cityDtos = _mapper.Map<List<CityDto>>(cities);
            return cityDtos;
        }

        public CityDto Get(int id)
        {
            var city = _cityRepository.Get(c => c.Id == id);
            var cityDto = _mapper.Map<CityDto>(city);
            return cityDto;
        }

        public Task<IEnumerable<City>> GetCitiesAsync(string name)
        {
            return _cityRepository.GetCitiesAsync(name);
        }
    }
}
