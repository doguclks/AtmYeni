﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.DPO;
using Atm.Api_1.Dto;
using Atm.Api_1.Pagination;
using Atm.Api_1.Services.Abstract;
using AutoMapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Atm.Api_1.Services.Concrete
{
    public class AtmMachineServices : IAtmMachineServices
    {
        private readonly IAtmMachineRepository _atmMachineRepository;
        private readonly IMapper _mapper;

        public AtmMachineServices(IAtmMachineRepository atmMachineRepository, IMapper mapper)
        {
            _atmMachineRepository = atmMachineRepository;
            _mapper = mapper;
        }

        public List<AtmMachineResponseDto> GetList()
        {
            var atmMachines = _atmMachineRepository.GetAll();
            //var atmMachineDtos = _mapper.Map<List<AtmMachineResponseDto>>(atmMachines);
            return atmMachines;
        }

        public AtmMachineResponseDto GetById(int id)
        {
            var atmMachine = _atmMachineRepository.GetById(id);
            //var atmMachineDto = _mapper.Map<AtmMachineResponseDto>(atmMachine);
            return atmMachine;
        }

        public async Task<bool> DeleteById(int id)
        {
            return await _atmMachineRepository.DeleteByIdAsync(id);
        }

        public async Task<bool> UpdateById(AtmMachine atmMachine, int id)
        {
            return await _atmMachineRepository.UpdateById(atmMachine, id);
        }

        public AtmMachineResponseDto Add(AtmMachineResponseDto atmMachineResponseDto)
        {
            var atmMachine = _mapper.Map<AtmMachine>(atmMachineResponseDto);
            _atmMachineRepository.Create(atmMachine);
            return _mapper.Map<AtmMachineResponseDto>(atmMachine);
        }

        public async Task<AtmMachine> Update(AtmMachine atmMachine)
        {
            return await _atmMachineRepository.Update(atmMachine);
        }
        public void Update2(AtmMachineDto dto)
        {


            var data = _atmMachineRepository.Get(x => x.Id == dto.Id);
            if (data != null)
            {

                data.Name = dto.Name;
                data.IsActive = dto.IsActive;
                data.Adress = dto.Adress;
                data.Latitude = dto.Latitude;
                data.Longitude = dto.Longitude;
                //data.CityId = dto.CityId;
                //data.DistrictId = dto.DistrictId;


            }
            _atmMachineRepository.SaveChanges();
        }
        public Task<PagedList<AtmMachineResponseDto>> Pagination(PagingParameters pagingParameters)
        {
            return _atmMachineRepository.Pagination(pagingParameters);
        }

    }
}
