﻿using Atm.Api_1.Data.Entities;

namespace Atm.Api_1.Dto
{
    public class CityDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<Districts> Districts { get; set; }
        public ICollection<AtmMachine> AtmMachines { get; set; }
    }
}
