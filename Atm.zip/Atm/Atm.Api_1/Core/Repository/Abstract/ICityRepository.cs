﻿using Atm.Api_1.Data.Entities;

namespace Atm.Api_1.Core.Repository.Abstract
{
    public interface ICityRepository : IBaseRepository<City>
    {
        Task<IEnumerable<City>> GetCitiesAsync(string name);
    }
    
}
