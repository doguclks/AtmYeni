﻿using Atm.Api_1.Data.Entities;
using Atm.Api_1.Dto;
using Atm.Api_1.Services.Concrete;
using System.Linq.Expressions;

namespace Atm.Api_1.Core.Repository.Abstract
{
    public interface IBaseRepository<TEntity>
    {

        //void Delete(TEntity entity);
        //void Add(TEntity entity);
        Task Create(TEntity entity);
        Task<bool> DeleteByIdAsync(int id);
        TEntity Get(Expression<Func<TEntity, bool>> filter);
        List<TEntity> GetAll(Expression<Func<TEntity, bool>> filter = null);
        //void Update(TEntity entity);
       
        Task<bool> UpdateById(TEntity entity, int id);
        void SaveChanges();

        IQueryable<AtmMachineResponseDto> FindAll();

    }
}
