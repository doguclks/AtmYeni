﻿using Atm.Api_1.Data.Entities;
using Atm.Api_1.Dto;
using Atm.Api_1.Pagination;

namespace Atm.Api_1.Core.Repository.Abstract
{
    public interface IAtmMachineRepository: IBaseRepository<AtmMachine>
    {
        
        AtmMachineResponseDto GetById(int id);
        Task<AtmMachine> Update(AtmMachine atmMachine);
        Task<IEnumerable<AtmMachine>> GetAtmMachinesWithDetailsAsync();
        List<AtmMachineResponseDto> GetAll();
        Task<PagedList<AtmMachineResponseDto>> Pagination(PagingParameters pagingParameters);



    }
}
