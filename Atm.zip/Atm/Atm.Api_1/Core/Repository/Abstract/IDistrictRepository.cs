﻿using Atm.Api_1.Data.Entities;

namespace Atm.Api_1.Core.Repository.Abstract
{
    public interface IDistrictRepository : IBaseRepository<Districts>
    {
        Task<IEnumerable<Districts>> GetDistrictsByCityNameAsync(int cityId);
    }
}
