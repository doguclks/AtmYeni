﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data;
using Atm.Api_1.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Atm.Api_1.Core.Repository.Concrete
{
    public class DistrictRepository : BaseRepository<Districts>, IDistrictRepository
    {
        private readonly AtmDbContext _context;
        public DistrictRepository(AtmDbContext context) : base(context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Districts>> GetDistrictsByCityNameAsync(int cityId)
        {
            return await _context.Districts
                .Where(d => d.CityId == cityId)
                .ToListAsync();
        }
    }
}
