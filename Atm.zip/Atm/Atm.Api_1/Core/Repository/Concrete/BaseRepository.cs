﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.Dto;
using Atm.Api_1.Services.Concrete;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;

namespace Atm.Api_1.Core.Repository.Concrete
{
    public class BaseRepository<TEntity> : IBaseRepository<TEntity>
        where TEntity : class, new()
    {
        private readonly AtmDbContext _context;
        public BaseRepository(AtmDbContext context)
        {

            _context = context;

        }

        //public void Add(TEntity entity)
        //{
        //    _context.Set<TEntity>().Add(entity);
        //    _context.SaveChanges();
        //}
        public async Task Create(TEntity entity)
        {
            _context.Set<TEntity>().Add(entity);
            _context.SaveChanges();
        }

        //public void Delete(TEntity entity)
        //{

        //    _context.Set<TEntity>().Remove(entity);
        //    _context.SaveChanges();

        //}
        public async Task<bool> DeleteByIdAsync(int id)
        {
            var entity = await _context.AtmMachines.FindAsync(id);
            if (entity == null)
            {
                return false;
            }

            _context.AtmMachines.Remove(entity);
            await _context.SaveChangesAsync();
            return true;
        }
        public TEntity Get(Expression<Func<TEntity, bool>> filter)
        {

            return _context.Set<TEntity>().SingleOrDefault(filter);

        }
        public List<TEntity> GetAll(Expression<Func<TEntity, bool>> filter = null)
        {


            return filter == null ? _context.Set<TEntity>().ToList() :
                _context.Set<TEntity>().Where(filter).ToList();


        }

        //public void Update(TEntity entity)
        //{


        //    _context.Set<TEntity>().Update(entity);
        //    _context.SaveChanges();

        //}
       

        public async Task<bool> UpdateById(TEntity entity, int id)
        {
            if (entity == null)
            {
                return false;
            }

            TEntity entity1 = await _context.Set<TEntity>().FindAsync(id);
            if (entity1 == null)
            {
                return false;
            }

            _context.Entry(entity1).CurrentValues.SetValues(entity);
            await _context.SaveChangesAsync();
            return true;
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
        public IQueryable<AtmMachineResponseDto> FindAll()
        {
            return this._context.Set<AtmMachineResponseDto>().AsNoTracking();
        }


    }
}
