﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data;
using Atm.Api_1.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Atm.Api_1.Core.Repository.Concrete
{
    public class CityRepository : BaseRepository<City>, ICityRepository
    {
        private readonly AtmDbContext _context;
        public CityRepository(AtmDbContext context) : base(context)
        {
        }
        public async Task<IEnumerable<City>> GetCitiesAsync(string name)
        {
            var query = _context.Cities.AsQueryable();

            if (!string.IsNullOrEmpty(name))
            {
                query = query.Where(c => c.Name.Contains(name));
            }
            
            return await query.ToListAsync();
        }

    }
}
