﻿using Atm.Api_1.Core.Repository.Abstract;
using Atm.Api_1.Data;
using Atm.Api_1.Data.Entities;
using Atm.Api_1.Dto;
using Atm.Api_1.Pagination;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atm.Api_1.Core.Repository.Concrete
{

    public class AtmMachineRepository : BaseRepository<AtmMachine>, IAtmMachineRepository
    {
        private readonly AtmDbContext _context;
        public AtmMachineRepository(AtmDbContext context) : base(context)
        {
            _context = context;
        }
        public async Task<AtmMachine> Update(AtmMachine atmMachine)
        {
            if (atmMachine == null)
            {
                throw new ArgumentNullException(nameof(atmMachine));
            }

            var existingAtmMachine = await _context.AtmMachines.FindAsync(atmMachine.Id);
            if (existingAtmMachine == null)
            {
                throw new KeyNotFoundException($"ATM makinesi bulunamadı: {atmMachine.Id}");
            }

            _context.Entry(existingAtmMachine).CurrentValues.SetValues(atmMachine);
            await _context.SaveChangesAsync();

            return existingAtmMachine;
        }
        public AtmMachineResponseDto GetById(int id)
        {
            var query = from atmMachine in _context.AtmMachines
                        join city in _context.Cities on atmMachine.CityId equals city.Id
                        join district in _context.Districts on atmMachine.DistrictId equals district.Id
                        where atmMachine.Id == id
                        select new AtmMachineResponseDto()
                        {
                            Id = atmMachine.Id,
                            Name = atmMachine.Name,
                            Latitude = atmMachine.Latitude,
                            Adress = atmMachine.Adress,
                            Longitude = atmMachine.Longitude,
                            DistrictId = atmMachine.DistrictId,
                            CityId = atmMachine.CityId,
                            CityName = city.Name,
                            DistrictName = district.Name,
                            IsActive = atmMachine.IsActive,


                        };
            return query.FirstOrDefault(); //ToList olucak getAll icin 
        }
        public List<AtmMachineResponseDto> GetAll()

        {
            var query = from atmMachine in _context.AtmMachines
                        join city in _context.Cities on atmMachine.CityId equals city.Id
                        join district in _context.Districts on atmMachine.DistrictId equals district.Id

                        select new AtmMachineResponseDto()
                        {
                            Id = atmMachine.Id,
                            Name = atmMachine.Name,
                            Latitude = atmMachine.Latitude,
                            Longitude = atmMachine.Longitude,
                            Adress = atmMachine.Adress,
                            DistrictId = atmMachine.DistrictId,
                            CityId = atmMachine.CityId,
                            CityName = city.Name,
                            DistrictName = district.Name,
                            IsActive = atmMachine.IsActive,
                        };
            return query.ToList();
        }
        public async Task<IEnumerable<AtmMachine>> GetAtmMachinesWithDetailsAsync()
        {
            return await _context.AtmMachines
                .Include(a => a.District)
                .ThenInclude(d => d.City)
                .ToListAsync();
        }

        public Task<PagedList<AtmMachineResponseDto>> Pagination(PagingParameters pagingParameters)
        {
            return Task.FromResult(PagedList<AtmMachineResponseDto>.GetPagedList(FindAll().OrderBy(s => s.Id), pagingParameters.PageNumber, pagingParameters.PageSize));
        }
       
       
    }
}
